var classpenify__hook_1_1api__client_1_1APIClient =
[
    [ "__init__", "classpenify__hook_1_1api__client_1_1APIClient.html#a8edae83711be6de381c6ec71c7aa2e37", null ],
    [ "generate_commit_summary", "classpenify__hook_1_1api__client_1_1APIClient.html#af0c2fac38629fed60e8440203a1197dd", null ],
    [ "generate_commit_summary_with_llm", "classpenify__hook_1_1api__client_1_1APIClient.html#a07bc97b2af31662029a24169f285c286", null ],
    [ "get_api_key", "classpenify__hook_1_1api__client_1_1APIClient.html#a57a96d5c14128dd8021347f7e72fe12b", null ],
    [ "get_supported_file_types", "classpenify__hook_1_1api__client_1_1APIClient.html#a5d2b4a26b24352d951ea79ecc4ff3402", null ],
    [ "send_file_for_docstring_generation", "classpenify__hook_1_1api__client_1_1APIClient.html#ad6392c5f8e8b5e3394a74979278835bd", null ],
    [ "api_url", "classpenify__hook_1_1api__client_1_1APIClient.html#a130cf688ed35dc0e8cbd8320b6b2d872", null ],
    [ "AUTH_TOKEN", "classpenify__hook_1_1api__client_1_1APIClient.html#a5bb502603717946ad710b49ad9d95237", null ],
    [ "BEARER_TOKEN", "classpenify__hook_1_1api__client_1_1APIClient.html#a7d7e2cf42c54eb4f25adee96a09ee7b0", null ]
];