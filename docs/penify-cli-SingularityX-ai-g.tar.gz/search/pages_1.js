var searchData=
[
  ['detailed_20usage_20guide_0',['Penify CLI - Detailed Usage Guide',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2detailed-usage.html',1,'']]],
  ['documentation_1',['penify-cli-documentation',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2penify-cli-documentation.html',1,'']]],
  ['documentation_20generation_20commands_2',['Penify CLI - Documentation Generation Commands',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2doc__commands.html',1,'']]]
];
