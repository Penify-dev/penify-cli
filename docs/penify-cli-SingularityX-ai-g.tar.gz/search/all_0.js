var searchData=
[
  ['1_3a_20efficient_20git_20commits_20with_20ai_0',['Workflow 1: Efficient Git Commits with AI',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2example-workflows.html#autotoc_md104',1,'']]]
];
