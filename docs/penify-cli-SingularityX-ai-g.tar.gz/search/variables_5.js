var searchData=
[
  ['entry_5fpoints_0',['entry_points',['../namespacesetup.html#ada7058afc98897f073d3f3b8b9157059',1,'setup']]],
  ['error_5fcolor_1',['ERROR_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a4ab4e61dfab7973c87bef59c6e1977fe',1,'penify_hook::ui_utils']]],
  ['error_5fsymbol_2',['ERROR_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#ae941d124e4d3aa294314d73fb47c6432',1,'penify_hook::ui_utils']]]
];
