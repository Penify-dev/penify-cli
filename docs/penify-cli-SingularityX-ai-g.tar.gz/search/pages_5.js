var searchData=
[
  ['usage_20guide_0',['Penify CLI - Detailed Usage Guide',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2detailed-usage.html',1,'']]]
];
