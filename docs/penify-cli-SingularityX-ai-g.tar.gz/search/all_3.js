var searchData=
[
  ['4_3a_20onboarding_20new_20team_20members_0',['Workflow 4: Onboarding New Team Members',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2SingularityX-ai_2penify-cli_2docs_2example-workflows.html#autotoc_md117',1,'']]]
];
