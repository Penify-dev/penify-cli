var searchData=
[
  ['add_5fcomment_0',['add_comment',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#aa1f374116c64cd5f1492ec7f7e40f9c1',1,'penify_hook::jira_client::JiraClient']]]
];
