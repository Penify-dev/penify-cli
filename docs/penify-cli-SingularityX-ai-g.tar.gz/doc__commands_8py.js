var doc__commands_8py =
[
    [ "penify_hook.commands.doc_commands.generate_doc", "namespacepenify__hook_1_1commands_1_1doc__commands.html#a0db2cb8c0446d85dc4e7d34b3929dad7", null ],
    [ "penify_hook.commands.doc_commands.handle_docgen", "namespacepenify__hook_1_1commands_1_1doc__commands.html#a41d631e51b0533b7d8dc780eea52e1cc", null ],
    [ "penify_hook.commands.doc_commands.setup_docgen_parser", "namespacepenify__hook_1_1commands_1_1doc__commands.html#abf64cb941e49af02798f5ff1b56139c6", null ],
    [ "penify_hook.commands.doc_commands.docgen_description", "namespacepenify__hook_1_1commands_1_1doc__commands.html#a6dd45546559198f9f79caccd030d3588", null ]
];