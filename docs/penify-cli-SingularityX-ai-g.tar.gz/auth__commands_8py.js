var auth__commands_8py =
[
    [ "penify_hook.commands.auth_commands.login", "namespacepenify__hook_1_1commands_1_1auth__commands.html#a1eb69ebcc475060011476a65cbffd7f6", null ],
    [ "penify_hook.commands.auth_commands.save_credentials", "namespacepenify__hook_1_1commands_1_1auth__commands.html#a68a2119363481a0001ad6190329c863b", null ]
];