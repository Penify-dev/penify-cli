var config__command_8py =
[
    [ "penify_hook.config_command.handle_config", "namespacepenify__hook_1_1config__command.html#aed769bb2e478b09003696b616edd04c5", null ],
    [ "penify_hook.config_command.setup_config_parser", "namespacepenify__hook_1_1config__command.html#ad711074006b3c5d4a1cc73ef38dcf0ba", null ]
];