var classpenify__hook_1_1llm__client_1_1LLMClient =
[
    [ "__init__", "classpenify__hook_1_1llm__client_1_1LLMClient.html#a699a5be4411f5847fcb0a170281ab14b", null ],
    [ "generate_commit_summary", "classpenify__hook_1_1llm__client_1_1LLMClient.html#a2ad3014dac466ee1d8e00306d0cf2000", null ],
    [ "litellm", "classpenify__hook_1_1llm__client_1_1LLMClient.html#aa646fddc43ecd633d2c358d58dd4df24", null ],
    [ "_litellm", "classpenify__hook_1_1llm__client_1_1LLMClient.html#a76c2e9805f805624ab9c55a9f1f8d362", null ],
    [ "model", "classpenify__hook_1_1llm__client_1_1LLMClient.html#abc2cb6b1d6d9b5dc16401ca078ec8c10", null ]
];