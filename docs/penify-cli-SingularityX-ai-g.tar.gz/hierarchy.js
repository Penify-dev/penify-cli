var hierarchy =
[
    [ "penify_hook.api_client.APIClient", "classpenify__hook_1_1api__client_1_1APIClient.html", null ],
    [ "penify_hook.base_analyzer.BaseAnalyzer", "classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html", [
      [ "penify_hook.commit_analyzer.CommitDocGenHook", "classpenify__hook_1_1commit__analyzer_1_1CommitDocGenHook.html", null ],
      [ "penify_hook.file_analyzer.FileAnalyzerGenHook", "classpenify__hook_1_1file__analyzer_1_1FileAnalyzerGenHook.html", null ],
      [ "penify_hook.folder_analyzer.FolderAnalyzerGenHook", "classpenify__hook_1_1folder__analyzer_1_1FolderAnalyzerGenHook.html", null ],
      [ "penify_hook.git_analyzer.GitDocGenHook", "classpenify__hook_1_1git__analyzer_1_1GitDocGenHook.html", null ]
    ] ],
    [ "Exception", "classException.html", [
      [ "penify_hook.utils.GitRepoNotFoundError", "classpenify__hook_1_1utils_1_1GitRepoNotFoundError.html", null ]
    ] ],
    [ "penify_hook.jira_client.JiraClient", "classpenify__hook_1_1jira__client_1_1JiraClient.html", null ],
    [ "penify_hook.llm_client.LLMClient", "classpenify__hook_1_1llm__client_1_1LLMClient.html", null ],
    [ "tests.test_commit_commands.TestCommitCommands", "classtests_1_1test__commit__commands_1_1TestCommitCommands.html", null ],
    [ "tests.test_config_commands.TestConfigCommands", "classtests_1_1test__config__commands_1_1TestConfigCommands.html", null ],
    [ "tests.test_web_config.TestWebConfig", "classtests_1_1test__web__config_1_1TestWebConfig.html", null ]
];