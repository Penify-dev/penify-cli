var login__command_8py =
[
    [ "penify_hook.login_command.handle_login", "namespacepenify__hook_1_1login__command.html#a13cdb8c8488b958ce536660a27521411", null ],
    [ "penify_hook.login_command.setup_login_parser", "namespacepenify__hook_1_1login__command.html#ae787794b007f320b4480aff0b9767235", null ]
];