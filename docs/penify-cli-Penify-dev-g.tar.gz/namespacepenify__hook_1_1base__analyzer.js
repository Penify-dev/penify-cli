var namespacepenify__hook_1_1base__analyzer =
[
    [ "BaseAnalyzer", "classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html", "classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer" ]
];