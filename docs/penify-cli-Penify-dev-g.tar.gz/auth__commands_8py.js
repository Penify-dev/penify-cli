var auth__commands_8py =
[
    [ "login", "auth__commands_8py.html#a78f375c58bb6f69f98675e6a9ac84655", null ],
    [ "save_credentials", "auth__commands_8py.html#aa3956ca1749d4218ea1dc6e5b6218b24", null ]
];