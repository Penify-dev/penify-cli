var constants_8py =
[
    [ "penify_hook.constants.API_URL", "namespacepenify__hook_1_1constants.html#a846767f047a1319005bc95395330ab34", null ],
    [ "penify_hook.constants.DASHBOARD_URL", "namespacepenify__hook_1_1constants.html#ae4a03ab3b19d60436c72484b313079c8", null ]
];