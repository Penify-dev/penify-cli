var constants_8py =
[
    [ "API_URL", "constants_8py.html#af198b5d1fc2f44657a2061aa324af3e0", null ],
    [ "DASHBOARD_URL", "constants_8py.html#a316c5a606e4440fb8224c6544c3a15f0", null ]
];