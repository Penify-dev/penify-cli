var login__command_8py =
[
    [ "handle_login", "login__command_8py.html#ae4bf932fbafeff834b0a0c5a37f74ccd", null ],
    [ "setup_login_parser", "login__command_8py.html#aae63db4c484797bead34b7d874020c6a", null ]
];