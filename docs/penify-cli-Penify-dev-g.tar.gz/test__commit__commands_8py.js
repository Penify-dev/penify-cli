var test__commit__commands_8py =
[
    [ "tests.test_commit_commands.TestCommitCommands", "classtests_1_1test__commit__commands_1_1TestCommitCommands.html", "classtests_1_1test__commit__commands_1_1TestCommitCommands" ]
];