var namespacepenify__hook_1_1llm__client =
[
    [ "LLMClient", "classpenify__hook_1_1llm__client_1_1LLMClient.html", "classpenify__hook_1_1llm__client_1_1LLMClient" ]
];