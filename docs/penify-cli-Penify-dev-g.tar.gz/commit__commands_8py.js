var commit__commands_8py =
[
    [ "penify_hook.commands.commit_commands.commit_code", "namespacepenify__hook_1_1commands_1_1commit__commands.html#a4360ebdd6821c714f9db99f8d447c1b6", null ],
    [ "penify_hook.commands.commit_commands.handle_commit", "namespacepenify__hook_1_1commands_1_1commit__commands.html#a7a856c3961f5f8914e58485644572076", null ],
    [ "penify_hook.commands.commit_commands.setup_commit_parser", "namespacepenify__hook_1_1commands_1_1commit__commands.html#a80d37e58f2dc4356ed99a54ac75b1db1", null ]
];