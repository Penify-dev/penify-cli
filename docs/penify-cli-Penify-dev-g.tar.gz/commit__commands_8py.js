var commit__commands_8py =
[
    [ "commit_code", "commit__commands_8py.html#a62564c4e8ad59fc46d56cb0f9122a71a", null ],
    [ "handle_commit", "commit__commands_8py.html#af4f739f524c38b437e4e47673d683e23", null ],
    [ "setup_commit_parser", "commit__commands_8py.html#a8627583116eb78e31a4d3cdc16d2f15c", null ]
];