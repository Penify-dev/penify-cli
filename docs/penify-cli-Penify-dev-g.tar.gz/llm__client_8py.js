var llm__client_8py =
[
    [ "penify_hook.llm_client.LLMClient", "classpenify__hook_1_1llm__client_1_1LLMClient.html", "classpenify__hook_1_1llm__client_1_1LLMClient" ]
];