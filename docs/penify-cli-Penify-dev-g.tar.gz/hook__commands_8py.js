var hook__commands_8py =
[
    [ "penify_hook.commands.hook_commands.install_git_hook", "namespacepenify__hook_1_1commands_1_1hook__commands.html#a093a68d1ec1b0da8ba8ab12a447fd135", null ],
    [ "penify_hook.commands.hook_commands.uninstall_git_hook", "namespacepenify__hook_1_1commands_1_1hook__commands.html#a1b2b3ffff51d19300a0b7ea785678443", null ],
    [ "penify_hook.commands.hook_commands.HOOK_FILENAME", "namespacepenify__hook_1_1commands_1_1hook__commands.html#a978b976442fbf28c29c8d0f889bfae9c", null ],
    [ "penify_hook.commands.hook_commands.HOOK_TEMPLATE", "namespacepenify__hook_1_1commands_1_1hook__commands.html#a51fc390518d967f2a1e21280d7ea781b", null ]
];