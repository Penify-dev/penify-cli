var hook__commands_8py =
[
    [ "install_git_hook", "hook__commands_8py.html#adff8f5d3bf1c3795974a391ee95b72b2", null ],
    [ "uninstall_git_hook", "hook__commands_8py.html#a81543eb5fa835fd1237f24e8bce6201d", null ],
    [ "HOOK_FILENAME", "hook__commands_8py.html#ae82fd46e5a9219da1478b0476b8214b1", null ],
    [ "HOOK_TEMPLATE", "hook__commands_8py.html#a6a45aad71c8d32ce11a6dff8cee8bee7", null ]
];