var classtests_1_1test__web__config_1_1TestWebConfig =
[
    [ "test_config_jira_web_server_setup", "classtests_1_1test__web__config_1_1TestWebConfig.html#a06e600222e426b003850509cb1d3190a", null ],
    [ "test_config_llm_web_server_setup", "classtests_1_1test__web__config_1_1TestWebConfig.html#afc6440352201d207ea8b4d26f8ccfa35", null ]
];