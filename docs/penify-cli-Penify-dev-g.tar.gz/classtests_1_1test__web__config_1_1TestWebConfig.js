var classtests_1_1test__web__config_1_1TestWebConfig =
[
    [ "test_config_jira_web_server_setup", "classtests_1_1test__web__config_1_1TestWebConfig.html#a63789aa9bfafe1a16b1f462174c53f6b", null ],
    [ "test_config_llm_web_server_setup", "classtests_1_1test__web__config_1_1TestWebConfig.html#a881cb29c7d44f302fb961f496a20776d", null ]
];