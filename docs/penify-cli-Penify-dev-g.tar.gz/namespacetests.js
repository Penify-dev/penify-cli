var namespacetests =
[
    [ "conftest", "namespacetests_1_1conftest.html", null ],
    [ "test_commit_commands", "namespacetests_1_1test__commit__commands.html", "namespacetests_1_1test__commit__commands" ],
    [ "test_config_commands", "namespacetests_1_1test__config__commands.html", "namespacetests_1_1test__config__commands" ],
    [ "test_doc_commands", "namespacetests_1_1test__doc__commands.html", [
      [ "test_generate_doc_error_handling", "namespacetests_1_1test__doc__commands.html#aec76cc25c23476794234cdadbcaef0c0", null ],
      [ "test_generate_doc_file_location", "namespacetests_1_1test__doc__commands.html#a0e74c920f258f442914771164fe26b45", null ],
      [ "test_generate_doc_folder_location", "namespacetests_1_1test__doc__commands.html#a4bb75610e40d94d42bc169b25403c186", null ],
      [ "test_generate_doc_no_location", "namespacetests_1_1test__doc__commands.html#a806110833eb0aad547156faf014b31d8", null ],
      [ "test_generate_doc_with_file_exception", "namespacetests_1_1test__doc__commands.html#a335e7fd4912192c7276cf31bbebc6eb0", null ],
      [ "test_generate_doc_with_folder_exception", "namespacetests_1_1test__doc__commands.html#a64165ddfdb3071a88422f080f0e529a3", null ],
      [ "test_handle_docgen_generate", "namespacetests_1_1test__doc__commands.html#ab158ffa48469b6c097a7a55fcb20c21a", null ],
      [ "test_handle_docgen_install_hook", "namespacetests_1_1test__doc__commands.html#ab74688baa8c9b5ba302c2877a9789d05", null ],
      [ "test_handle_docgen_no_token", "namespacetests_1_1test__doc__commands.html#af9b01e5fc89255cac96747fa081c442c", null ],
      [ "test_handle_docgen_uninstall_hook", "namespacetests_1_1test__doc__commands.html#a1458af9ad0128c3ca1263b552fd5e482", null ],
      [ "test_setup_docgen_parser", "namespacetests_1_1test__doc__commands.html#a0f27751d0ba2acfe40ef7e85bccf47d7", null ]
    ] ],
    [ "test_web_config", "namespacetests_1_1test__web__config.html", "namespacetests_1_1test__web__config" ]
];