var namespacetests =
[
    [ "conftest", "namespacetests_1_1conftest.html", null ],
    [ "test_commit_commands", "namespacetests_1_1test__commit__commands.html", "namespacetests_1_1test__commit__commands" ],
    [ "test_config_commands", "namespacetests_1_1test__config__commands.html", "namespacetests_1_1test__config__commands" ],
    [ "test_doc_commands", "namespacetests_1_1test__doc__commands.html", [
      [ "test_generate_doc_error_handling", "namespacetests_1_1test__doc__commands.html#a5fe1bfd9eacf8775c20f9a883fcc10a6", null ],
      [ "test_generate_doc_file_location", "namespacetests_1_1test__doc__commands.html#ac12eb3d9839af7f9cfc2da5150ac8a16", null ],
      [ "test_generate_doc_folder_location", "namespacetests_1_1test__doc__commands.html#a161b89af34978ec9f4a59a37f374125d", null ],
      [ "test_generate_doc_no_location", "namespacetests_1_1test__doc__commands.html#a709237fc294b8309acdaddd29369f15b", null ],
      [ "test_generate_doc_with_file_exception", "namespacetests_1_1test__doc__commands.html#a28ffc568a6338124fce4eff50a839f68", null ],
      [ "test_generate_doc_with_folder_exception", "namespacetests_1_1test__doc__commands.html#a8f073a1ebba4bf58fa0875f01b372fee", null ],
      [ "test_handle_docgen_generate", "namespacetests_1_1test__doc__commands.html#a8adc7be503bd092e118f9454fffbd0d5", null ],
      [ "test_handle_docgen_install_hook", "namespacetests_1_1test__doc__commands.html#a278af7079be277ff3eab96e7e8c038b9", null ],
      [ "test_handle_docgen_no_token", "namespacetests_1_1test__doc__commands.html#a27e497ab63419dcd4ce066864882aa0c", null ],
      [ "test_handle_docgen_uninstall_hook", "namespacetests_1_1test__doc__commands.html#abe2161b459ab5d033d6ba997323c218b", null ],
      [ "test_setup_docgen_parser", "namespacetests_1_1test__doc__commands.html#a15204cf3fb17527d46e54316576f2042", null ]
    ] ],
    [ "test_web_config", "namespacetests_1_1test__web__config.html", "namespacetests_1_1test__web__config" ]
];