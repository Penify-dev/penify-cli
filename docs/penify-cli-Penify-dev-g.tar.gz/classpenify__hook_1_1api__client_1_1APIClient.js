var classpenify__hook_1_1api__client_1_1APIClient =
[
    [ "__init__", "classpenify__hook_1_1api__client_1_1APIClient.html#ad9cb741a8baf2d13f845e25a36311086", null ],
    [ "generate_commit_summary", "classpenify__hook_1_1api__client_1_1APIClient.html#a7ff74798e7d428b4e2f20095287eb2ce", null ],
    [ "generate_commit_summary_with_llm", "classpenify__hook_1_1api__client_1_1APIClient.html#ac0ada470b897935f9fb372cd0e7e51e3", null ],
    [ "get_api_key", "classpenify__hook_1_1api__client_1_1APIClient.html#ad15b790608e703c8c122aa2ead7dfa99", null ],
    [ "get_supported_file_types", "classpenify__hook_1_1api__client_1_1APIClient.html#a5d2b4a26b24352d951ea79ecc4ff3402", null ],
    [ "send_file_for_docstring_generation", "classpenify__hook_1_1api__client_1_1APIClient.html#ac5aad61508c2cafdf6e88e6c7d6c82b3", null ],
    [ "api_url", "classpenify__hook_1_1api__client_1_1APIClient.html#a130cf688ed35dc0e8cbd8320b6b2d872", null ],
    [ "AUTH_TOKEN", "classpenify__hook_1_1api__client_1_1APIClient.html#a5bb502603717946ad710b49ad9d95237", null ],
    [ "BEARER_TOKEN", "classpenify__hook_1_1api__client_1_1APIClient.html#a7d7e2cf42c54eb4f25adee96a09ee7b0", null ]
];