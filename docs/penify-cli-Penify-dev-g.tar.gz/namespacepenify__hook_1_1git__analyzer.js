var namespacepenify__hook_1_1git__analyzer =
[
    [ "GitDocGenHook", "classpenify__hook_1_1git__analyzer_1_1GitDocGenHook.html", "classpenify__hook_1_1git__analyzer_1_1GitDocGenHook" ],
    [ "logger", "namespacepenify__hook_1_1git__analyzer.html#ac4ce143fdca789a79c66852c37d7363a", null ]
];