var namespacepenify__hook_1_1commit__analyzer =
[
    [ "CommitDocGenHook", "classpenify__hook_1_1commit__analyzer_1_1CommitDocGenHook.html", "classpenify__hook_1_1commit__analyzer_1_1CommitDocGenHook" ]
];