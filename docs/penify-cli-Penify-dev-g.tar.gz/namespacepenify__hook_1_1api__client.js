var namespacepenify__hook_1_1api__client =
[
    [ "APIClient", "classpenify__hook_1_1api__client_1_1APIClient.html", "classpenify__hook_1_1api__client_1_1APIClient" ]
];