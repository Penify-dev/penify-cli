var searchData=
[
  ['fileanalyzergenhook_0',['FileAnalyzerGenHook',['../classpenify__hook_1_1file__analyzer_1_1FileAnalyzerGenHook.html',1,'penify_hook::file_analyzer']]],
  ['folderanalyzergenhook_1',['FolderAnalyzerGenHook',['../classpenify__hook_1_1folder__analyzer_1_1FolderAnalyzerGenHook.html',1,'penify_hook::folder_analyzer']]]
];
