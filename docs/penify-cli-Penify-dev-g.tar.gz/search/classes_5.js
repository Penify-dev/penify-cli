var searchData=
[
  ['gitdocgenhook_0',['GitDocGenHook',['../classpenify__hook_1_1git__analyzer_1_1GitDocGenHook.html',1,'penify_hook::git_analyzer']]],
  ['gitreponotfounderror_1',['GitRepoNotFoundError',['../classpenify__hook_1_1utils_1_1GitRepoNotFoundError.html',1,'penify_hook::utils']]]
];
