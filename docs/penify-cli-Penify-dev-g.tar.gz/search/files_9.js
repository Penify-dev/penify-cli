var searchData=
[
  ['jira_5fclient_2epy_0',['jira_client.py',['../jira__client_8py.html',1,'']]]
];
