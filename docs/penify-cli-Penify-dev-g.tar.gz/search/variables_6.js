var searchData=
[
  ['file_5fpath_0',['file_path',['../classpenify__hook_1_1file__analyzer_1_1FileAnalyzerGenHook.html#a9b03b88a9ce1b9af945279375048dc32',1,'penify_hook::file_analyzer::FileAnalyzerGenHook']]],
  ['folder_5fpath_1',['folder_path',['../classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html#aa67c06dd12b1bafaeaee81c41dcb7e25',1,'penify_hook::base_analyzer::BaseAnalyzer']]]
];
