var searchData=
[
  ['llmclient_0',['LLMClient',['../classpenify__hook_1_1llm__client_1_1LLMClient.html',1,'penify_hook::llm_client']]]
];
