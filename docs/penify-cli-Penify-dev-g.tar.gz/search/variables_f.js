var searchData=
[
  ['success_5fcolor_0',['SUCCESS_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a22c450c5e2b5394618ecf9b636560df4',1,'penify_hook::ui_utils']]],
  ['success_5fsymbol_1',['SUCCESS_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#a3c6fe4bd17c1a5fe76587225ae4beb3e',1,'penify_hook::ui_utils']]],
  ['supported_5ffile_5ftypes_2',['supported_file_types',['../classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html#a0cac0310ec635aa64a34857cf30ce1eb',1,'penify_hook::base_analyzer::BaseAnalyzer']]]
];
