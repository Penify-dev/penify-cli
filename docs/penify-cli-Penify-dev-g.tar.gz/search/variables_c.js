var searchData=
[
  ['name_0',['name',['../namespacesetup.html#ab3a7a0638d76a01367c5bc3cc699447f',1,'setup']]],
  ['neutral_5fcolor_1',['NEUTRAL_COLOR',['../namespacepenify__hook_1_1ui__utils.html#aca0fcee81606857497520ae4290bc9f5',1,'penify_hook::ui_utils']]]
];
