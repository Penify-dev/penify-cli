var searchData=
[
  ['info_5fcolor_0',['INFO_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a9fdcb180915696f5d217032a62c3857c',1,'penify_hook::ui_utils']]],
  ['install_5frequires_1',['install_requires',['../namespacesetup.html#abead4f26b530856f858f0d44c7cf2588',1,'setup']]]
];
