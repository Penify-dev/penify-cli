var searchData=
[
  ['highlight_5fcolor_0',['HIGHLIGHT_COLOR',['../namespacepenify__hook_1_1ui__utils.html#aba01b8259f0d66cdc2b4a1b58f9736fc',1,'penify_hook::ui_utils']]],
  ['hook_5ffilename_1',['HOOK_FILENAME',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#ae82fd46e5a9219da1478b0476b8214b1',1,'penify_hook::commands::hook_commands']]],
  ['hook_5ftemplate_2',['HOOK_TEMPLATE',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#a6a45aad71c8d32ce11a6dff8cee8bee7',1,'penify_hook::commands::hook_commands']]]
];
