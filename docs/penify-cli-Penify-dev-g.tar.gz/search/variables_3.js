var searchData=
[
  ['classifiers_0',['classifiers',['../namespacesetup.html#abe96a9c38c1c61f9f0fdb002c482f785',1,'setup']]]
];
