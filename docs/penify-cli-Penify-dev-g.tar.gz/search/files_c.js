var searchData=
[
  ['penify_2dcli_2ddocumentation_2emd_0',['penify-cli-documentation.md',['../penify-cli-documentation_8md.html',1,'']]]
];
