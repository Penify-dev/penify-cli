var searchData=
[
  ['generation_20commands_0',['Penify CLI - Documentation Generation Commands',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2doc__commands.html',1,'']]],
  ['guide_1',['Penify CLI - Detailed Usage Guide',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2detailed-usage.html',1,'']]]
];
