var searchData=
[
  ['commitdocgenhook_0',['CommitDocGenHook',['../classpenify__hook_1_1commit__analyzer_1_1CommitDocGenHook.html',1,'penify_hook::commit_analyzer']]]
];
