var searchData=
[
  ['baseanalyzer_0',['BaseAnalyzer',['../classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html',1,'penify_hook::base_analyzer']]]
];
