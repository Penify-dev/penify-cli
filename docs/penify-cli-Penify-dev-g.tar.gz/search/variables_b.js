var searchData=
[
  ['model_0',['model',['../classpenify__hook_1_1llm__client_1_1LLMClient.html#abc2cb6b1d6d9b5dc16401ca078ec8c10',1,'penify_hook::llm_client::LLMClient']]]
];
