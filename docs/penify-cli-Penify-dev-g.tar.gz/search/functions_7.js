var searchData=
[
  ['install_5fgit_5fhook_0',['install_git_hook',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#adff8f5d3bf1c3795974a391ee95b72b2',1,'penify_hook::commands::hook_commands']]],
  ['is_5fconnected_1',['is_connected',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#a00d0f9ae006313a21576362d26ac5ec8',1,'penify_hook::jira_client::JiraClient']]]
];
