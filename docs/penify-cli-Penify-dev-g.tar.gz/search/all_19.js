var searchData=
[
  ['variables_0',['Variables',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2config-commands.html#autotoc_md36',1,'Environment Variables'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md153',1,'Environment Variables']]],
  ['verifying_20installation_1',['Verifying Installation',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2doc__commands.html#autotoc_md85',1,'']]],
  ['verifying_20uninstallation_2',['Verifying Uninstallation',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2doc__commands.html#autotoc_md93',1,'']]],
  ['version_3',['version',['../namespacesetup.html#a2aa722b36a933088812b50ea79b97a5c',1,'setup']]]
];
