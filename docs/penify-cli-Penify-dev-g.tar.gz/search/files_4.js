var searchData=
[
  ['detailed_2dusage_2emd_0',['detailed-usage.md',['../detailed-usage_8md.html',1,'']]],
  ['doc_5fcommands_2emd_1',['doc_commands.md',['../doc__commands_8md.html',1,'']]],
  ['doc_5fcommands_2epy_2',['doc_commands.py',['../doc__commands_8py.html',1,'']]]
];
