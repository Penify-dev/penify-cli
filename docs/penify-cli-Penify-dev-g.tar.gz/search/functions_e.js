var searchData=
[
  ['uninstall_5fgit_5fhook_0',['uninstall_git_hook',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#a1b2b3ffff51d19300a0b7ea785678443',1,'penify_hook::commands::hook_commands']]],
  ['update_5fissue_5fstatus_1',['update_issue_status',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#aca8837552d37bfd611de23441a240826',1,'penify_hook::jira_client::JiraClient']]],
  ['update_5fstage_2',['update_stage',['../namespacepenify__hook_1_1ui__utils.html#ad8be9c5a2708c211a651e2b3dfb54bcd',1,'penify_hook::ui_utils']]]
];
