var searchData=
[
  ['3_3a_20code_20review_20enhancement_0',['Workflow 3: Code Review Enhancement',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md113',1,'']]]
];
