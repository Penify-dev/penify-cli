var searchData=
[
  ['warning_5fcolor_0',['WARNING_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a177bc9b44157844c999e0c1c2c6936ff',1,'penify_hook::ui_utils']]],
  ['warning_5fsymbol_1',['WARNING_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#a6eaea98f1a8cbe16a181647da2fc0a16',1,'penify_hook::ui_utils']]]
];
