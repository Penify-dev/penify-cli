var base__analyzer_8py =
[
    [ "penify_hook.base_analyzer.BaseAnalyzer", "classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer.html", "classpenify__hook_1_1base__analyzer_1_1BaseAnalyzer" ]
];