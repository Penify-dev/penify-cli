var doc__commands_8py =
[
    [ "generate_doc", "doc__commands_8py.html#a4daac68bc563432bf25c85dc78081a25", null ],
    [ "handle_docgen", "doc__commands_8py.html#a2006ab13bff718ef783868a910c0b704", null ],
    [ "setup_docgen_parser", "doc__commands_8py.html#acc7f4ead1b11951d885fa5c151c2cbe0", null ],
    [ "docgen_description", "doc__commands_8py.html#a3e42540047da37565afffeaf106cb948", null ]
];