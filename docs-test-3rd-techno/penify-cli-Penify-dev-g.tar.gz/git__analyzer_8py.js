var git__analyzer_8py =
[
    [ "penify_hook.git_analyzer.GitDocGenHook", "classpenify__hook_1_1git__analyzer_1_1GitDocGenHook.html", "classpenify__hook_1_1git__analyzer_1_1GitDocGenHook" ],
    [ "penify_hook.git_analyzer.logger", "namespacepenify__hook_1_1git__analyzer.html#ac4ce143fdca789a79c66852c37d7363a", null ]
];