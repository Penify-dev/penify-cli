var searchData=
[
  ['2_3a_20documentation_20generation_20pipeline_0',['Workflow 2: Documentation Generation Pipeline',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md108',1,'']]]
];
