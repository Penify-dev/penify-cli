var searchData=
[
  ['warning_5fcolor_0',['WARNING_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a177bc9b44157844c999e0c1c2c6936ff',1,'penify_hook::ui_utils']]],
  ['warning_5fsymbol_1',['WARNING_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#a9ee7a42eeca5b12429cb97bf89007be8',1,'penify_hook::ui_utils']]]
];
