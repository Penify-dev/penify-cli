var searchData=
[
  ['highlight_5fcolor_0',['HIGHLIGHT_COLOR',['../namespacepenify__hook_1_1ui__utils.html#aba01b8259f0d66cdc2b4a1b58f9736fc',1,'penify_hook::ui_utils']]],
  ['hook_5ffilename_1',['HOOK_FILENAME',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#a978b976442fbf28c29c8d0f889bfae9c',1,'penify_hook::commands::hook_commands']]],
  ['hook_5ftemplate_2',['HOOK_TEMPLATE',['../namespacepenify__hook_1_1commands_1_1hook__commands.html#a51fc390518d967f2a1e21280d7ea781b',1,'penify_hook::commands::hook_commands']]]
];
