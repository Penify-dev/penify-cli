var searchData=
[
  ['name_0',['name',['../namespacesetup.html#ab3a7a0638d76a01367c5bc3cc699447f',1,'setup']]],
  ['neutral_5fcolor_1',['NEUTRAL_COLOR',['../namespacepenify__hook_1_1ui__utils.html#aca0fcee81606857497520ae4290bc9f5',1,'penify_hook::ui_utils']]],
  ['new_20team_20members_2',['New Team Members',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md119',1,'For New Team Members'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md117',1,'Workflow 4: Onboarding New Team Members']]],
  ['no_20login_20required_3',['Basic Commands (No login required)',['..//app/doc_state/github_reposRepoArchDocGenContext/Penify-dev/penify-cli/README.md#autotoc_md160',1,'']]]
];
