var searchData=
[
  ['packages_0',['packages',['../namespacesetup.html#aff2375a361fd5865c77bd9aa093be747',1,'setup']]],
  ['path_1',['path',['../namespacepenify__hook_1_1commands_1_1config__commands.html#a79fceaf7882b9bcf1075a24262c5d7e2',1,'penify_hook::commands::config_commands']]],
  ['processing_5fsymbol_2',['PROCESSING_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#ad7cc8eaf7a660ff195f4366d792ab155',1,'penify_hook::ui_utils']]],
  ['python_5frequires_3',['python_requires',['../namespacesetup.html#aa7ca7bc9391b217e81efeb03689d8dbf',1,'setup']]]
];
