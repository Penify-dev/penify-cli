var searchData=
[
  ['example_20workflows_0',['Penify CLI Example Workflows',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html',1,'']]]
];
