var searchData=
[
  ['jiraclient_0',['JiraClient',['../classpenify__hook_1_1jira__client_1_1JiraClient.html',1,'penify_hook::jira_client']]]
];
