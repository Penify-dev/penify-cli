var searchData=
[
  ['5_3a_20legacy_20code_20understanding_0',['Workflow 5: Legacy Code Understanding',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md121',1,'']]]
];
