var searchData=
[
  ['e_20terminal_20tt_0',['&lt;tt&gt;-e, --terminal&lt;/tt&gt;',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2commit-commands.html#autotoc_md4',1,'']]],
  ['edit_20and_20provide_20context_1',['Generate, Edit, and Provide Context',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2commit-commands.html#autotoc_md10',1,'']]],
  ['edit_20full_20commit_20message_2',['Generate and Edit Full Commit Message',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2commit-commands.html#autotoc_md9',1,'']]],
  ['efficient_20git_20commits_20with_20ai_3',['Workflow 1: Efficient Git Commits with AI',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md104',1,'']]],
  ['enhance_5fcommit_5fmessage_4',['enhance_commit_message',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#a70d2c5a6432aa6f238da0ff65d49a760',1,'penify_hook::jira_client::JiraClient']]],
  ['enhancement_5',['Enhancement',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2commit-commands.html#autotoc_md13',1,'JIRA Enhancement'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html#autotoc_md113',1,'Workflow 3: Code Review Enhancement']]],
  ['entry_5fpoints_6',['entry_points',['../namespacesetup.html#ada7058afc98897f073d3f3b8b9157059',1,'setup']]],
  ['environment_20variables_7',['Environment Variables',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2config-commands.html#autotoc_md36',1,'Environment Variables'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md153',1,'Environment Variables']]],
  ['error_5fcolor_8',['ERROR_COLOR',['../namespacepenify__hook_1_1ui__utils.html#a4ab4e61dfab7973c87bef59c6e1977fe',1,'penify_hook::ui_utils']]],
  ['error_5fsymbol_9',['ERROR_SYMBOL',['../namespacepenify__hook_1_1ui__utils.html#ae941d124e4d3aa294314d73fb47c6432',1,'penify_hook::ui_utils']]],
  ['example_20workflows_10',['Penify CLI Example Workflows',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2example-workflows.html',1,'']]],
  ['example_2dworkflows_2emd_11',['example-workflows.md',['../example-workflows_8md.html',1,'']]],
  ['example_3a_12',['Example:',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md144',1,'']]],
  ['examples_13',['Examples',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2commit-commands.html#autotoc_md15',1,'']]],
  ['examples_3a_14',['Examples:',['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md133',1,'Examples:'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md139',1,'Examples:'],['../md__2app_2doc__state_2github__reposRepoArchDocGenContext_2Penify-dev_2penify-cli_2docs_2penify-cli-documentation.html#autotoc_md150',1,'Examples:']]],
  ['exception_15',['Exception',['../classException.html',1,'']]],
  ['extract_5fissue_5fkeys_16',['extract_issue_keys',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#ad2823ad1d3baaedd38039913c3a97fd7',1,'penify_hook::jira_client::JiraClient']]],
  ['extract_5fissue_5fkeys_5ffrom_5fbranch_17',['extract_issue_keys_from_branch',['../classpenify__hook_1_1jira__client_1_1JiraClient.html#a093d6456fe053ef7a7862d5d6851910c',1,'penify_hook::jira_client::JiraClient']]]
];
