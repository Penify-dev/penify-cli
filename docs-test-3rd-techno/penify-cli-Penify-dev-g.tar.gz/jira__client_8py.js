var jira__client_8py =
[
    [ "penify_hook.jira_client.JiraClient", "classpenify__hook_1_1jira__client_1_1JiraClient.html", "classpenify__hook_1_1jira__client_1_1JiraClient" ],
    [ "penify_hook.jira_client.JIRA_AVAILABLE", "namespacepenify__hook_1_1jira__client.html#a5593ea3415081eca1eea92e4c1ad1aa2", null ]
];