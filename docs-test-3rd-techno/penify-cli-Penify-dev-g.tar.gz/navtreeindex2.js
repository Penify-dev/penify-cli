var NAVTREEINDEX2 =
{
"penify__hook_2____init_____8py.html":[8,0,0,1,1],
"penify__hook_2commands_2____init_____8py.html":[8,0,0,1,0,0],
"setup_8py.html":[8,0,0,3],
"test__commit__commands_8py.html":[8,0,0,2,2],
"test__config__commands_8py.html":[8,0,0,2,3],
"test__doc__commands_8py.html":[8,0,0,2,4],
"test__web__config_8py.html":[8,0,0,2,5],
"tests_2____init_____8py.html":[8,0,0,2,0],
"ui__utils_8py.html":[8,0,0,1,14],
"utils_8py.html":[8,0,0,1,15]
};
